// 响应式交互处理
class ResponsiveHandler {
    constructor() {
        this.isMobile = window.innerWidth < 768;
        this.isTablet = window.innerWidth >= 768 && window.innerWidth < 992;
        this.sidebar = null;
        this.backdrop = null;
        this.menuToggle = null;
        this.touchStartX = null;
        this.touchStartY = null;
        
        this.init();
    }
    
    init() {
        // 创建移动端元素
        this.createMobileElements();
        
        // 绑定事件
        this.bindEvents();
        
        // 初始化响应式状态
        this.handleResize();
    }
    
    createMobileElements() {
        // 创建移动端菜单按钮
        if (!document.querySelector('.mobile-menu-toggle')) {
            const menuToggle = document.createElement('button');
            menuToggle.className = 'mobile-menu-toggle';
            menuToggle.innerHTML = '<i class="bi bi-list"></i>';
            menuToggle.setAttribute('aria-label', '切换菜单');
            document.body.appendChild(menuToggle);
            this.menuToggle = menuToggle;
        }
        
        // 创建遮罩层
        if (!document.querySelector('.sidebar-backdrop')) {
            const backdrop = document.createElement('div');
            backdrop.className = 'sidebar-backdrop';
            document.body.appendChild(backdrop);
            this.backdrop = backdrop;
        }
        
        // 获取侧边栏
        const sidebarCol = document.querySelector('.col-md-3');
        if (sidebarCol) {
            sidebarCol.classList.add('sidebar-column');
            this.sidebar = sidebarCol;
        }
        
        // 获取主聊天区
        const chatCol = document.querySelector('.col-md-9');
        if (chatCol) {
            chatCol.classList.add('chat-column');
        }
    }
    
    bindEvents() {
        // 窗口大小改变事件
        window.addEventListener('resize', this.debounce(() => {
            this.handleResize();
        }, 250));
        
        // 移动端菜单切换
        if (this.menuToggle) {
            this.menuToggle.addEventListener('click', () => {
                this.toggleSidebar();
            });
        }
        
        // 遮罩层点击关闭
        if (this.backdrop) {
            this.backdrop.addEventListener('click', () => {
                this.closeSidebar();
            });
        }
        
        // 触摸手势支持
        if (this.isMobile || this.isTablet) {
            this.initTouchGestures();
        }
        
        // 处理对话列表项点击（移动端自动关闭侧边栏）
        document.addEventListener('click', (e) => {
            const conversationItem = e.target.closest('.conversation-item');
            if (conversationItem && (this.isMobile || this.isTablet)) {
                setTimeout(() => this.closeSidebar(), 100);
            }
        });
    }
    
    initTouchGestures() {
        const messageContainer = document.getElementById('message-container');
        if (!messageContainer) return;
        
        // 添加触摸滑动支持
        let touchStartX = 0;
        let touchStartY = 0;
        let touchEndX = 0;
        let touchEndY = 0;
        
        messageContainer.addEventListener('touchstart', (e) => {
            touchStartX = e.changedTouches[0].screenX;
            touchStartY = e.changedTouches[0].screenY;
        }, { passive: true });
        
        messageContainer.addEventListener('touchend', (e) => {
            touchEndX = e.changedTouches[0].screenX;
            touchEndY = e.changedTouches[0].screenY;
            this.handleSwipe(touchStartX, touchStartY, touchEndX, touchEndY);
        }, { passive: true });
        
        // 边缘滑动打开侧边栏
        document.addEventListener('touchstart', (e) => {
            const touch = e.changedTouches[0];
            if (touch.screenX < 20 && !this.sidebar?.classList.contains('show')) {
                this.touchStartX = touch.screenX;
                this.touchStartY = touch.screenY;
            }
        }, { passive: true });
        
        document.addEventListener('touchmove', (e) => {
            if (this.touchStartX !== null) {
                const touch = e.changedTouches[0];
                const deltaX = touch.screenX - this.touchStartX;
                const deltaY = Math.abs(touch.screenY - this.touchStartY);
                
                if (deltaX > 50 && deltaY < 30) {
                    this.openSidebar();
                    this.touchStartX = null;
                    this.touchStartY = null;
                }
            }
        }, { passive: true });
    }
    
    handleSwipe(startX, startY, endX, endY) {
        const deltaX = endX - startX;
        const deltaY = Math.abs(endY - startY);
        const threshold = 50; // 最小滑动距离
        
        // 确保主要是水平滑动
        if (Math.abs(deltaX) > threshold && deltaY < threshold) {
            if (deltaX > 0 && this.sidebar && !this.sidebar.classList.contains('show')) {
                // 右滑打开侧边栏
                this.openSidebar();
            } else if (deltaX < 0 && this.sidebar?.classList.contains('show')) {
                // 左滑关闭侧边栏
                this.closeSidebar();
            }
        }
    }
    
    handleResize() {
        const newWidth = window.innerWidth;
        const wasMobile = this.isMobile;
        
        this.isMobile = newWidth < 768;
        this.isTablet = newWidth >= 768 && newWidth < 992;
        
        // 从移动端切换到桌面端
        if (wasMobile && !this.isMobile && !this.isTablet) {
            this.closeSidebar();
            if (this.sidebar) {
                this.sidebar.style.position = '';
                this.sidebar.style.left = '';
                this.sidebar.style.width = '';
                this.sidebar.style.height = '';
            }
        }
        
        // 调整输入框行数
        const messageInput = document.getElementById('message-input');
        if (messageInput) {
            if (this.isMobile) {
                messageInput.rows = 2;
            } else {
                messageInput.rows = 3;
            }
        }
    }
    
    toggleSidebar() {
        if (this.sidebar?.classList.contains('show')) {
            this.closeSidebar();
        } else {
            this.openSidebar();
        }
    }
    
    openSidebar() {
        if (this.sidebar) {
            this.sidebar.classList.add('show');
            this.backdrop?.classList.add('show');
            document.body.style.overflow = 'hidden'; // 防止背景滚动
            
            // 更新菜单按钮图标
            if (this.menuToggle) {
                this.menuToggle.innerHTML = '<i class="bi bi-x"></i>';
            }
        }
    }
    
    closeSidebar() {
        if (this.sidebar) {
            this.sidebar.classList.remove('show');
            this.backdrop?.classList.remove('show');
            document.body.style.overflow = ''; // 恢复滚动
            
            // 更新菜单按钮图标
            if (this.menuToggle) {
                this.menuToggle.innerHTML = '<i class="bi bi-list"></i>';
            }
        }
    }
    
    // 防抖函数
    debounce(func, wait) {
        let timeout;
        return function executedFunction(...args) {
            const later = () => {
                clearTimeout(timeout);
                func(...args);
            };
            clearTimeout(timeout);
            timeout = setTimeout(later, wait);
        };
    }
    
    // 优化滚动性能
    optimizeScrolling() {
        const messageContainer = document.getElementById('message-container');
        if (!messageContainer) return;
        
        let ticking = false;
        
        function updateScrollPosition() {
            // 可以在这里添加滚动相关的优化，比如懒加载
            ticking = false;
        }
        
        messageContainer.addEventListener('scroll', () => {
            if (!ticking) {
                window.requestAnimationFrame(updateScrollPosition);
                ticking = true;
            }
        }, { passive: true });
    }
    
    // 添加键盘快捷键支持
    initKeyboardShortcuts() {
        document.addEventListener('keydown', (e) => {
            // Ctrl/Cmd + / 打开/关闭侧边栏
            if ((e.ctrlKey || e.metaKey) && e.key === '/') {
                e.preventDefault();
                this.toggleSidebar();
            }
        });
    }
}

// 主题管理器
class ThemeManager {
    constructor() {
        this.currentTheme = localStorage.getItem('theme') || 'light';
        this.init();
    }
    
    init() {
        // 应用保存的主题
        this.applyTheme(this.currentTheme);
        
        // 创建主题切换按钮
        this.createThemeToggle();
        
        // 监听系统主题变化
        if (window.matchMedia) {
            window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', (e) => {
                if (!localStorage.getItem('theme')) {
                    this.applyTheme(e.matches ? 'dark' : 'light');
                }
            });
        }
    }
    
    createThemeToggle() {
        // 在导航栏添加主题切换按钮
        const navbar = document.querySelector('.navbar-nav:last-child');
        if (navbar) {
            const themeToggle = document.createElement('li');
            themeToggle.className = 'nav-item';
            themeToggle.innerHTML = `
                <button class="nav-link btn btn-link" id="theme-toggle" title="切换主题">
                    <i class="bi ${this.currentTheme === 'dark' ? 'bi-sun-fill' : 'bi-moon-fill'}"></i>
                </button>
            `;
            navbar.insertBefore(themeToggle, navbar.firstChild);
            
            // 绑定点击事件
            document.getElementById('theme-toggle').addEventListener('click', () => {
                this.toggleTheme();
            });
        }
    }
    
    toggleTheme() {
        const newTheme = this.currentTheme === 'light' ? 'dark' : 'light';
        this.applyTheme(newTheme);
        localStorage.setItem('theme', newTheme);
    }
    
    applyTheme(theme) {
        this.currentTheme = theme;
        document.documentElement.setAttribute('data-theme', theme);
        
        // 更新图标
        const themeToggle = document.getElementById('theme-toggle');
        if (themeToggle) {
            themeToggle.innerHTML = `<i class="bi ${theme === 'dark' ? 'bi-sun-fill' : 'bi-moon-fill'}"></i>`;
        }
        
        // 更新meta标签
        const metaTheme = document.querySelector('meta[name="theme-color"]');
        if (metaTheme) {
            metaTheme.content = theme === 'dark' ? '#111827' : '#6366f1';
        } else {
            const meta = document.createElement('meta');
            meta.name = 'theme-color';
            meta.content = theme === 'dark' ? '#111827' : '#6366f1';
            document.head.appendChild(meta);
        }
    }
}

// 初始化
document.addEventListener('DOMContentLoaded', () => {
    // 初始化响应式处理器
    window.responsiveHandler = new ResponsiveHandler();
    
    // 初始化主题管理器
    window.themeManager = new ThemeManager();
    
    // 添加键盘快捷键
    window.responsiveHandler.initKeyboardShortcuts();
    
    // 优化滚动性能
    window.responsiveHandler.optimizeScrolling();
});
