// This file previously contained the ChatStateManager class definition.
// The active state manager instance is now created by the IIFE in state_manager.js.
// This file is kept (but empty) to avoid potential 404 errors if something still tries to load it,
// and to prevent accidental re-creation of the conflicting class definition.
